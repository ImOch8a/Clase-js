var carro = document.querySelector('.car')
var fondo = document.querySelector('.bg')
var llantas = document.querySelector('.wheels')
var llanta2 = document.querySelector('.wheels2')
var polvo = document.querySelector('.polvo')
var luz = document.querySelector('.luz')

carro.addEventListener('click', animations)

function animations() {
    fondo.classList.add('bg_animado')
    llantas.classList.add('wheels_animado')
    llanta2.classList.add('wheels2_animado')
    polvo.classList.remove('oculto')
    luz.classList.remove('oculto2')
}